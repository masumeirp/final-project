<?php
session_start();
?>
<html>
<head>
<meta charset="UTF-8" />
<title>فروشگاه ايرانيان</title>
</head>

<body>

<style type="text/css">
<!--
	.set_style_link {
     text-decoration: none;
     font-weight: bold;
     }
-->
</style>
<table dir="rtl"  style="font-family: tahoma;font-size: 13pt;width: 1024px;margin-left: auto;margin-right: auto;"   >
    <tr>
        <td>

            <table style="width: 100%;"  border="1"  >
                <tr style="text-align:center">
	               <td>لوگوی سايت</td>
                </tr>
            </table>

				

            <table style="width: 100%;"  border="1"  >
                <tr style="text-align: center;">
                    <td><a href="index.php" class="set_style_link" >صفحه اصلی</a></td>
                    <td><a href="register.php"  class="set_style_link" >عضويت در سايت</a></td>
                    <?php
					    //در صورت ورود کاربر پیوند خروج از سایت به همراه نام واقعی کاربر نمایش داده می شود
                        if (isset($_SESSION["state_login"]) && $_SESSION["state_login"]===true) 
                         {
                    ?>
                    <td><a href="logout.php"  class="set_style_link" >خروج از سایت <?php echo(" ({$_SESSION["realname"]}) ") ?></a></td>
                    <?php
                         } // if  پایان
						 //در صورت عدم ورود کاربر پیوند ورود به سایت نمایش داده می شود
                        else
                         { 
                    ?>
                    <td><a href="login.php"  class="set_style_link" >ورود به سايت</a></td>
                    <?php
                         }  //else پایان 
                    ?>
                    <td><a href="darbarey ma"  class="set_style_link" >درباره ما</a></td>
                    <td><a href="contact.php"  class="set_style_link" >ارتباط با ما</a></td>
                    
                    <?php
					//درصورتی که کاربر وارد شده به سایت مدیر باشد لینک مدیریت محصولات و مدیریت سفارشات به انتهای منوی بالای سایت اضافه می شود
                        if (isset($_SESSION["state_login"]) && $_SESSION["state_login"]===true && $_SESSION["user_type"]=="admin") 
                         {
                    ?>
                    <td><a href="admin_products.php"  class="set_style_link" >مدیریت محصولات</a></td>                    
                    <td><a href="admin_manage_order.php"  class="set_style_link" >مدیریت سفارشات</a></td>
                    <?php
                         } // if  پایان
                    ?>
                    
                </tr>
            </table>
            
			<!-- جدول نگهدارنده موقعیت بخش های امکانات سایت و نمایش محصولات -->

			<table style="width: 100%;"  border="1"  >
                <tr>
                    <td style="width: 25%;">بخش امكانات سايت</td>
                    <td style="width: 75%;">